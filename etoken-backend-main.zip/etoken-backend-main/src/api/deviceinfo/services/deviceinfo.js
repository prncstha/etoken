'use strict';

/**
 * deviceinfo service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::deviceinfo.deviceinfo');
